<!DOCTYPE html>
<html>
  <head>
    <title>ChartJS - BarGraph</title>
    <style type="text/css">
      -moz-user-select: none;
        -webkit-user-select: none;
        -ms-user-select: none;
    </style>
  </head>
  <body>
    <div id="container" style = "width: 75%;">
      <canvas id="mycanvas"></canvas>     
    </div>

    <!-- javascript -->
    <script type="text/javascript" src="http://localhost/ci/assets/js/js/jquery.min.js"></script>
    <script type="text/javascript" src="http://localhost/ci/assets/js/js/Chart.min.js"></script>
    <script type="text/javascript">
      
//////

      var subject = [];
      var term_1 = [];
      var term_2 = [];
      var term_3 = [];
      var ctx = $("#mycanvas");
      var horizontalBarChartData;
      var barGraph;
      var type = 'horizontalBar';
      
      
      var randomColorGenerator = function () { 
      return '#' + (Math.random().toString(16) + '0000000').slice(2, 8); 
    };
    

   

var data = <?php 
  echo json_encode($results) ?>;
      
      subject.push("Maths");
      subject.push("Science");
      subject.push("Religion");
      subject.push("History");
      subject.push("English");
      subject.push("Language");
            
      
        term_1.push(data[0].Maths);
        term_1.push(data[0].Science);
        term_1.push(data[0].Religion);
        term_1.push(data[0].History);
        term_1.push(data[0].English);
        term_1.push(data[0].Language);
        
        term_2.push(data[1].Maths);
        term_2.push(data[1].Science);
        term_2.push(data[1].Religion);
        term_2.push(data[1].History);
        term_2.push(data[1].English);
        term_2.push(data[1].Language);
        
        term_3.push(data[2].Maths);
        term_3.push(data[2].Science);
        term_3.push(data[2].Religion);
        term_3.push(data[2].History);
        term_3.push(data[2].English);
        term_3.push(data[2].Language);
      
      

      

window.onload = function(){
       window.barGraph = new Chart(ctx, {
        type: type,
        data: horizontalBarChartData,
        options: {
                    // Elements options apply to all of the options unless overridden in a dataset
                    // In this case, we are setting the border of each horizontal bar to be 2px wide
                    elements: {
                        rectangle: {
                            borderWidth: 1,
                        }
                    },
                    responsive: true,
                    legend: {
                        position: 'right',
                    },
                    title: {
                        display: true,
                        text: 'Name of the Student'
                    },
          scales: {
                    xAxes: [{
                        display: true,
                        scaleLabel: {
                            display: true,
                            labelString: 'MARK'
                        }
                    }],
                    yAxes: [{
                        display: true,
                        scaleLabel: {
                            display: true,
                            labelString: 'SUBJECT'
                        }
                    }]
          }
                }
                
      });
      
 };     
  
    
  
  var color = Chart.helpers.color;
  horizontalBarChartData = {
        labels: subject,
        datasets : [
          {
            type:'horizontalBar',         
            label: 'Term Test 1',
            backgroundColor: randomColorGenerator(),             
            data: term_1
          },
          {
            type:'horizontalBar',         
            label: 'Term Test 2',
            backgroundColor: randomColorGenerator(),                                  
            data: term_2
          },
          {
            type:'horizontalBar',         
            label:'Term Test 3',
            backgroundColor: randomColorGenerator(),                                
            data: term_3
          }
          
          
          
        ]
      };
  

    






    </script>
  </body>
</html>