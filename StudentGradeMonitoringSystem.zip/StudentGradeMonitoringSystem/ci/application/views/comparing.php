<!DOCTYPE html>
<html>
<head>
    <title>Combo Bar-Line Chart</title>
    <script src="http://localhost/ci/assets/js/js/Chart.bundle.js"></script>
    <script src="http://localhost/ci/assets/js/js/utils.js"></script>
    <style>
    canvas {
        -moz-user-select: none;
        -webkit-user-select: none;
        -ms-user-select: none;
    }
    </style>
</head>

<body>
    <div style="width: 75%">
        <canvas id="mycanvas"></canvas>
    </div>
   
	
		<script type="text/javascript" src="http://localhost/ci/assets/js/js/jquery.min.js"></script>
		<script type="text/javascript" src="http://localhost/ci/assets/js/js/Chart.min.js"></script>
		<script type="text/javascript">
		
		
			var id = [];
			var year_1 = [];
			var year_2 = [];								
			var ctx = $("#mycanvas");
			var chartdata;
			var barGraphs;
			
			
				
			var randomColorGenerator = function () { 
			return '#' + (Math.random().toString(16) + '0000000').slice(2, 8); 
		};
		
		
			var color_1 = randomColorGenerator();
			var color_2 = randomColorGenerator();



var data =<?php 
//header('content-Type: application/json');

define('DB_HOST','localhost');
define('DB_uNAME','root');
define('DB_PASSWORD','');
define('DB_NAME','csv');

$mysqli = new mysqli(DB_HOST,DB_uNAME,DB_PASSWORD,DB_NAME);

if(!$mysqli){
	die("Connection failed:");
}
switch($grade){
	case 'Class6':
		switch($term){
			case '1':
$query = "SELECT a.indexno as indexno1,(a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 as Average1, FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr6_1_2010_ol as a)) AS rank,b.indexno as indexno2, (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 as Average2 FROM gr6_1_2010_OL as a,gr6_1_2011_ol as b Where ( FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr6_1_2010_ol as a)) )=(FIND_IN_SET( b.indexno, (SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr6_1_2011_ol as b))) ORDER BY Average1 DESC" ;
			break;
			case '2':
$query = "SELECT a.indexno as indexno1,(a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 as Average1, FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr6_2_2010_ol as a)) AS rank,b.indexno as indexno2, (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 as Average2 FROM gr6_2_2010_OL as a,gr6_2_2011_ol as b Where ( FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr6_2_2010_ol as a)) )=(FIND_IN_SET( b.indexno, (SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr6_2_2011_ol as b))) ORDER BY Average1 DESC" ;
			break;
			case '3':
$query = "SELECT a.indexno as indexno1,(a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 as Average1, FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr6_3_2010_ol as a)) AS rank,b.indexno as indexno2, (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 as Average2 FROM gr6_3_2010_OL as a,gr6_3_2011_ol as b Where ( FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr6_3_2010_ol as a)) )=(FIND_IN_SET( b.indexno, (SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr6_3_2011_ol as b))) ORDER BY Average1 DESC" ;
			break;
		}
break;

case 'Class7':
switch($term){
			case '1':
$query = "SELECT a.indexno as indexno1,(a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 as Average1, FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr7_1_2010_ol as a)) AS rank,b.indexno as indexno2, (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 as Average2 FROM gr7_1_2010_OL as a,gr7_1_2011_ol as b Where ( FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr7_1_2010_ol as a)) )=(FIND_IN_SET( b.indexno, (SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr7_1_2011_ol as b))) ORDER BY Average1 DESC" ;
			break;
			case '2':
$query = "SELECT a.indexno as indexno1,(a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 as Average1, FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr7_2_2010_ol as a)) AS rank,b.indexno as indexno2, (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 as Average2 FROM gr7_2_2010_OL as a,gr7_2_2011_ol as b Where ( FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr7_2_2010_ol as a)) )=(FIND_IN_SET( b.indexno, (SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr7_2_2011_ol as b))) ORDER BY Average1 DESC" ;
			break;
			case '3':
$query = "SELECT a.indexno as indexno1,(a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 as Average1, FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr7_3_2010_ol as a)) AS rank,b.indexno as indexno2, (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 as Average2 FROM gr7_3_2010_OL as a,gr7_3_2011_ol as b Where ( FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr7_3_2010_ol as a)) )=(FIND_IN_SET( b.indexno, (SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr7_3_2011_ol as b))) ORDER BY Average1 DESC" ;
			break;
		}
break;

case 'Class8':
switch($term){
			case '1':
$query = "SELECT a.indexno as indexno1,(a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 as Average1, FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr8_1_2010_ol as a)) AS rank,b.indexno as indexno2, (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 as Average2 FROM gr8_1_2010_OL as a,gr8_1_2011_ol as b Where ( FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr8_1_2010_ol as a)) )=(FIND_IN_SET( b.indexno, (SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr8_1_2011_ol as b))) ORDER BY Average1 DESC" ;
			break;
			case '2':
$query = "SELECT a.indexno as indexno1,(a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 as Average1, FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr8_2_2010_ol as a)) AS rank,b.indexno as indexno2, (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 as Average2 FROM gr8_2_2010_OL as a,gr8_2_2011_ol as b Where ( FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr8_2_2010_ol as a)) )=(FIND_IN_SET( b.indexno, (SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr8_2_2011_ol as b))) ORDER BY Average1 DESC" ;
			break;
			case '3':
$query = "SELECT a.indexno as indexno1,(a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 as Average1, FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr8_3_2010_ol as a)) AS rank,b.indexno as indexno2, (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 as Average2 FROM gr8_3_2010_OL as a,gr8_3_2011_ol as b Where ( FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr8_3_2010_ol as a)) )=(FIND_IN_SET( b.indexno, (SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr8_3_2011_ol as b))) ORDER BY Average1 DESC" ;
			break;
		}
break;

case 'Class9':
switch($term){
			case '1':
$query = "SELECT a.indexno as indexno1,(a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 as Average1, FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr9_1_2010_ol as a)) AS rank,b.indexno as indexno2, (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 as Average2 FROM gr9_1_2010_OL as a,gr9_1_2011_ol as b Where ( FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr9_1_2010_ol as a)) )=(FIND_IN_SET( b.indexno, (SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr9_1_2011_ol as b))) ORDER BY Average1 DESC" ;
			break;
			case '2':
$query = "SELECT a.indexno as indexno1,(a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 as Average1, FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr9_2_2010_ol as a)) AS rank,b.indexno as indexno2, (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 as Average2 FROM gr9_2_2010_OL as a,gr9_2_2011_ol as b Where ( FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr9_2_2010_ol as a)) )=(FIND_IN_SET( b.indexno, (SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr9_2_2011_ol as b))) ORDER BY Average1 DESC" ;
			break;
			case '3':
$query = "SELECT a.indexno as indexno1,(a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 as Average1, FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr9_3_2010_ol as a)) AS rank,b.indexno as indexno2, (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 as Average2 FROM gr9_3_2010_OL as a,gr9_3_2011_ol as b Where ( FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr9_3_2010_ol as a)) )=(FIND_IN_SET( b.indexno, (SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr9_3_2011_ol as b))) ORDER BY Average1 DESC" ;
			break;
		}
break;

case 'Class10':
switch($term){
			case '1':
$query = "SELECT a.indexno as indexno1,(a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 as Average1, FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr_10_1_2010_ol as a)) AS rank,b.indexno as indexno2, (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 as Average2 FROM gr_10_2010_OL as a,gr10_1_2011_ol as b Where ( FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr10_1_2010_ol as a)) )=(FIND_IN_SET( b.indexno, (SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr10_1_2011_ol as b))) ORDER BY Average1 DESC" ;
			break;
			case '2':
$query = "SELECT a.indexno as indexno1,(a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 as Average1, FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr10_2_2010_ol as a)) AS rank,b.indexno as indexno2, (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 as Average2 FROM gr10_2_2010_OL as a,gr10_2_2011_ol as b Where ( FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr10_2_2010_ol as a)) )=(FIND_IN_SET( b.indexno, (SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr10_2_2011_ol as b))) ORDER BY Average1 DESC" ;
			break;
			case '3':
$query = "SELECT a.indexno as indexno1,(a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 as Average1, FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr10_3_2010_ol as a)) AS rank,b.indexno as indexno2, (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 as Average2 FROM gr10_3_2010_OL as a,gr10_3_2011_ol as b Where ( FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr10_3_2010_ol as a)) )=(FIND_IN_SET( b.indexno, (SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr10_3_2011_ol as b))) ORDER BY Average1 DESC" ;
			break;
		}
break;

case 'Class11':
switch($term){
			case '1':
$query = "SELECT a.indexno as indexno1,(a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 as Average1, FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr11_1_2010_ol as a)) AS rank,b.indexno as indexno2, (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 as Average2 FROM gr11_1_2010_OL as a,gr11_1_2011_ol as b Where ( FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr11_1_2010_ol as a)) )=(FIND_IN_SET( b.indexno, (SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr11_1_2011_ol as b))) ORDER BY Average1 DESC" ;
			break;
			case '2':
$query = "SELECT a.indexno as indexno1,(a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 as Average1, FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr11_2_2010_ol as a)) AS rank,b.indexno as indexno2, (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 as Average2 FROM gr11_2_2010_OL as a,gr11_2_2011_ol as b Where ( FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr11_2_2010_ol as a)) )=(FIND_IN_SET( b.indexno, (SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr11_2_2011_ol as b))) ORDER BY Average1 DESC" ;
			break;
			case '3':
$query = "SELECT a.indexno as indexno1,(a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 as Average1, FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr11_3_2010_ol as a)) AS rank,b.indexno as indexno2, (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 as Average2 FROM gr11_3_2010_OL as a,gr11_3_2011_ol as b Where ( FIND_IN_SET( a.indexno, (SELECT GROUP_CONCAT( a.indexno ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) FROM gr11_3_2010_ol as a)) )=(FIND_IN_SET( b.indexno, (SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr11_3_2011_ol as b))) ORDER BY Average1 DESC" ;
			break;
		}
break;
}
$result =mysqli_query($mysqli,$query);

$data = array();
 while($row =mysqli_fetch_assoc($result))
    {
        $data[] = $row;
    }


mysqli_close($mysqli);

echo json_encode($data);

 ?>;

 for(var i in data){
				id.push(data[i].rank);
				year_1.push(data[i].Average1);
				year_2.push(data[i].Average2);
								
			}
			
			
			
			
		 window.onload = function(){	
			window.barGraphs = new Chart(ctx, {
				type: 'line',
				data: chartdata,
				options: {
					responsive: true,
                    legend: {
                        position: 'top',
                    },
					title: {
                        display: true,
                        text: 'SELECTED CLASS ALL SUBJETS MARKS ANALYSE'
                    },
					scales: {
                    xAxes: [{
                        display: true,
                        scaleLabel: {
                            display: true,
                            labelString: 'INDEX NUMBER'
                        }
                    }],
                    yAxes: [{
                        display: true,
                        scaleLabel: {
                            display: true,
                            labelString: 'MARK'
                        }
                    }]
                }
										
					
				}
				
								
			});
			
			
		 };	



chartdata = { 
				labels: id,
				datasets : [
					{	

						type: 'line', 
						data: year_1,
						fill:false,
						label: 'Year 1',
						backgroundColor: color_1,
						borderColor: color_1,
						borderWidth: 2,
						
					},					
					{	

						type: 'line', 
						data:year_2,
						fill:false,
						label: 'Year 2',
						backgroundColor: color_2,
						borderColor:color_2,
						borderWidth: 2,
						
					},					
					
					
					
					
				]
			};		 
			
			
			
			
		</script>

	
</body>


</html>			