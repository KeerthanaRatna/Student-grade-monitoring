<?php 
	$conn = mysqli_connect("localhost","root","","csv") or die(mysqli_error());
	//mysqli_select_db("csv",$conn);

	if(isset($_POST['submit']))
	{
		$file = $_FILES['file']['tmp_name'];
	
		$handle = fopen($file,"r");
		
		while(($fileop = fgetcsv($handle,1000,",")) !== false)
		{
			$indexno = $fileop[0];
			$firstname = $fileop[1];
			$lastname = $fileop[2];
			$Maths = $fileop[3];
			$English = $fileop[4];
			$History = $fileop[5];
			$Science = $fileop[6];
			$Religion = $fileop[7];
			$Language = $fileop[8];
			$buck1 = $fileop[9];
			$buck2 = $fileop[10];
			$buck3 = $fileop[11];
			$year= $fileop[12];
			$grade=$fileop[13];
			$term=$fileop[14];
			
			$sql = mysqli_query("INSERT INTO demo(indexno,firstname,lastname,Maths,English,History,Science,Religion,Language,buck1,buck2,buck3,year,grade,term) VALUES('$indexno','$firstname','$lastname','$Maths','$English','$History','$Science','$Religion','$Language','$buck1','$buck2','$buck3',$year,$grade,$term)");
			}
			
			if($sql)
			{
			echo 'data uploaded successfully';
			}
		
	
	
	
	}



?>
<!DOCTYPE html>
<html>
<head lang="en">
    <title>Browse page</title>
   <meta charset="utf-8" />
	<link rel="icon" type="image/png" href="http://localhost/ci/assets/img/favicon.ico">		
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />





<div class="wrapper">
    <div class="sidebar" data-color="white" data-image="http://localhost/ci/assets/img/sidebar-8.jpg">

    <!--

        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag

    -->

    	<div class="sidebar-wrapper">
            <div class="logo">
                <a  class="simple-text">
                    <div><h2><b>Welcome</b></h2></div>
                    <div><h3><b>Student Grade Monitoring System</b></h3></div>  
                </a>
            </div>

            <ul class="nav">
                <li class="active">
                    <a href="dashb">
                        <i class="pe-7s-graph"></i>
                        <p><font size="3">Dashboard</font></p>
                    </a>
                </li>
                <li>
                    <a href="user">
                        <i class="pe-7s-user"></i>
                        <p><font size="3">User Profile</font></p>
                    </a>
                </li>                              
               
				<li>
                    <a href="browse">
                        <i class="pe-7s-upload"></i>
                        <p><font size="3">Upload Marks</font></p>
                    </a>
                </li>
				
            </ul>
    	</div>
    </div>

  
	  
	   <style >
    body{

        background-image:url("http://localhost/ci/assets/img/bbc.jpg");
    }


    </style>
	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="http://localhost/ci/assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="http://localhost/ci/assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="http://localhost/ci/assets/css/light-bootstrap-dashboard.css" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="http://localhost/ci/assets/css/demo.css" rel="stylesheet" />


    <!--     Fonts and icons     -->
    <link href="http://localhost/ci/assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="http://localhost/ci/assets/css/googlefont.css" rel='stylesheet' type='text/css'>
    <link href="http://localhost/ci/assets/css/pe-icon-7-stroke.css" rel="stylesheet" />

	
	
</head>

<body>


	  
	<div id="mainWrapper">
	
	
	
	
				
<br /><br /><br /><br />
	
		<form method="post" action="browse" enctype="multipart/form-data" style="margin-left:600px;">
		 
		<input type="file" name="file" align="middle" style="width:250px; height:50px;" /> 
			
	
			
			
			<br /><br /><br />
			
			<button class="btn btn-default btn-lg" type="submit"><b><font size="7" color="black">Submit</font></b></button>
			
			
			
			
			
			
		</form>
		
	
	
	
	</div>
	
	<!--  Scripts-->
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="http://localhost/ci/assets/js/js/materialize.js"></script>
  <script src="http://localhost/ci/assets/js/js/init.js"></script>
   <!--   Core JS Files   -->
    <script src="http://localhost/ci/assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="http://localhost/ci/assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="http://localhost/ci/assets/js/bootstrap-checkbox-radio-switch.js"></script>

	<!--  Charts Plugin -->
	<script src="http://localhost/ci/assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="http://localhost/ci/assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
   
    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="http://localhost/ci/assets/js/light-bootstrap-dashboard.js"></script>

	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
	<script src="http://localhost/ci/assets/js/demo.js"></script>

	<script type="text/javascript">

	

	
	

</body>
</html>