<!DOCTYPE html>
<html>
<head>
    <title>Combo Bar-Line Chart</title>
    <script src="http://localhost/ci/assets/js/js/Chart.bundle.js"></script>
    <script src="http://localhost/ci/assets/js/js/utils.js"></script>
    <style>
    canvas {
        -moz-user-select: none;
        -webkit-user-select: none;
        -ms-user-select: none;
    }
    </style>
</head>

<body>
    <div style="width: 75%">
        <canvas id="mycanvas"></canvas>
    </div>
   
  
    <script type="text/javascript" src="http://localhost/ci/assets/js/js/jquery.min.js"></script>
    <script type="text/javascript" src="http://localhost/ci/assets/js/js/Chart.min.js"></script>
    <script type="text/javascript">
      var id = [];
      var maths_mark = [];
      var science_mark = [];
      var english_mark = [];
      var language_mark = [];
      var ctx = $("#mycanvas");
      var chartdata;
      var barGraphs;
      var color_1;
      var color_2;
      var color_3;
      var color_4;
    
    
        
            var randomColorGenerator = function () { 
      return '#' + (Math.random().toString(16) + '0000000').slice(2, 8); 
    };
      
      
      color_1 = randomColorGenerator();
      color_2 = randomColorGenerator();
      color_3 = randomColorGenerator();
      color_4 = randomColorGenerator();


var data= <?php 

define('DB_HOST','localhost');
define('DB_uNAME','root');
define('DB_PASSWORD','');
define('DB_NAME','csv');

$mysqli = new mysqli(DB_HOST,DB_uNAME,DB_PASSWORD,DB_NAME);

if(!$mysqli){
	die("Connection failed:");
}


if($this->input->post("index")< 100){
$query= "(SELECT a.Grade as Class,a.$subject as Term_1,b.$subject as Term_2,c.$subject as Term_3, (a.$subject+b.$subject+c.$subject)/3 as Average FROM gr6_1_2010_OL as a,gr6_2_2010_OL as b,gr6_3_2010_OL as c WHERE (a.indexno=$index) AND (b.indexno=$index) AND (c.indexno=$index))
UNION (SELECT d.Grade as Class,d.$subject as Term_1,e.$subject as Term_2,f.$subject as Term_3, (d.$subject+e.$subject+f.$subject)/3 as Average FROM gr7_1_2010_OL as d,gr7_2_2010_OL as e,gr7_3_2010_OL as f WHERE (d.indexno=$index) AND (e.indexno=$index) AND (f.indexno=$index))
UNION (SELECT g.Grade as Class,g.$subject as Term_1,h.$subject as Term_2,i.$subject as Term_3, (g.$subject+h.$subject+i.$subject)/3 as Average FROM gr8_1_2010_OL as g,gr8_2_2010_OL as h,gr8_3_2010_OL as i WHERE (g.indexno=$index) AND (h.indexno=$index) AND (i.indexno=$index)) 
UNION (SELECT j.Grade as Class,j.$subject as Term_1,k.$subject as Term_2,l.$subject as Term_3, (j.$subject+k.$subject+l.$subject)/3 as Average FROM gr9_1_2010_OL as j,gr9_2_2010_OL as k,gr9_3_2010_OL as l WHERE (j.indexno=$index) AND (k.indexno=$index) AND (l.indexno=$index))
UNION (SELECT m.Grade as Class,m.$subject as Term_1,n.$subject as Term_2,o.$subject as Term_3, (m.$subject+n.$subject+o.$subject)/3 as Average FROM gr10_1_2010_OL as m,gr10_2_2010_OL as n,gr10_3_2010_OL as o WHERE (m.indexno=$index) AND (n.indexno=$index) AND (o.indexno=$index))
UNION (SELECT p.Grade as Class,p.$subject as Term_1,q.$subject as Term_2,r.$subject as Term_3, (p.$subject+q.$subject+r.$subject)/3 as Average FROM gr11_1_2010_OL as p,gr11_2_2010_OL as q,gr11_3_2010_OL as r WHERE (p.indexno=$index) AND (q.indexno=$index) AND (r.indexno=$index)) "; 
}

if($this->input->post("index") >100){
$query= "(SELECT a.Grade as Class,a.$subject as Term_1,b.$subject as Term_2,c.$subject as Term_3, (a.$subject+b.$subject+c.$subject)/3 as Average FROM gr6_1_2011_OL as a,gr6_2_2011_OL as b,gr6_3_2011_OL as c WHERE (a.indexno=$index) AND (b.indexno=$index) AND (c.indexno=$index))
UNION (SELECT d.Grade as Class,d.$subject as Term_1,e.$subject as Term_2,f.$subject as Term_3, (d.$subject+e.$subject+f.$subject)/3 as Average FROM gr7_1_2011_OL as d,gr7_2_2011_OL as e,gr7_3_2011_OL as f WHERE (d.indexno=$index) AND (e.indexno=$index) AND (f.indexno=$index))
UNION (SELECT g.Grade as Class,g.$subject as Term_1,h.$subject as Term_2,i.$subject as Term_3, (g.$subject+h.$subject+i.$subject)/3 as Average FROM gr8_1_2011_OL as g,gr8_2_2011_OL as h,gr8_3_2011_OL as i WHERE (g.indexno=$index) AND (h.indexno=$index) AND (i.indexno=$index)) 
UNION (SELECT j.Grade as Class,j.$subject as Term_1,k.$subject as Term_2,l.$subject as Term_3, (j.$subject+k.$subject+l.$subject)/3 as Average FROM gr9_1_2011_OL as j,gr9_2_2011_OL as k,gr9_3_2011_OL as l WHERE (j.indexno=$index) AND (k.indexno=$index) AND (l.indexno=$index))
UNION (SELECT m.Grade as Class,m.$subject as Term_1,n.$subject as Term_2,o.$subject as Term_3, (m.$subject+n.$subject+o.$subject)/3 as Average FROM gr10_1_2011_OL as m,gr10_2_2011_OL as n,gr10_3_2011_OL as o WHERE (m.indexno=$index) AND (n.indexno=$index) AND (o.indexno=$index))
UNION (SELECT p.Grade as Class,p.$subject as Term_1,q.$subject as Term_2,r.$subject as Term_3, (p.$subject+q.$subject+r.$subject)/3 as Average FROM gr11_1_2011_OL as p,gr11_2_2011_OL as q,gr11_3_2011_OL as r WHERE (p.indexno=$index) AND (q.indexno=$index) AND (r.indexno=$index)) "; 
}



$result =mysqli_query($mysqli,$query);

$data = array();
 while($row =mysqli_fetch_assoc($result))
    {
        $data[] = $row;
    }

//$result_close();

mysqli_close($mysqli);

echo json_encode($data);



?>;

for(var i in data){
        id.push(data[i].Class);
        maths_mark.push(data[i].Term_1);
        science_mark.push(data[i].Term_2);
        english_mark.push(data[i].Term_3);
        language_mark.push(data[i].Average);
        
      }
        
        window.onload = function(){
        window.barGraphs = new Chart(ctx, {
        type: 'line',
        data: chartdata,
        options: {
          responsive: true,
                    legend: {
                        position: 'top',
                    },
          title: {
                        display: true,
                        text: 'SELECTED STUDENT SELECTED SUBJECT MARKS VARIATION'
                    },
          scales: {
                    xAxes: [{
                        display: true,
                        scaleLabel: {
                            display: true,
                            labelString: 'CLASS'
                        }
                    }],
                    yAxes: [{
                        display: true,
                        scaleLabel: {
                            display: true,
                            labelString: 'MARK'
                        }
                    }]
                }
                    
          
        }
        
                
      });
        };  
        
        
        chartdata = { 
        labels: id,
        datasets : [
          { 

            type: 'line', 
            data: maths_mark,
            fill:false,
            label: 'Term-1',
            backgroundColor: color_1,
            borderColor: color_1,
            borderWidth: 2,
          },
          
          { 

            type: 'line', 
            data:science_mark,
            fill:false,
            label: 'Term-2',
            backgroundColor: color_4,
            borderColor: color_4,
            borderWidth: 2,
          },
          
          
          { 

            type: 'line', 
            data: english_mark,
            fill:false,
            label:'Term-3',
            backgroundColor: color_2,
            borderColor: color_2,
            borderWidth: 2,
          },          
          { 

            type: 'line', 
            data: language_mark,
            fill:false,
            label: 'Average of the year',
            backgroundColor: color_3,
            borderColor: color_3,
            borderWidth: 2,
          },

          
          
          
          
        ]
      };
        
        
        
      </script>

  
</body>


</html> 