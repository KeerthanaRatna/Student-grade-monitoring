<?php
    $host="localhost"; // Host name.
    $db_user="root"; // MySQL username.
    $db_password=""; // MySQL password.
    $database="login"; // Database name.

  
    $link = mysqli_connect($host,$db_user,$db_password,$database);
    if (!$link) {
       die('Could not connect: ' . mysqli_error());
    }
     $username=$_POST['username'];
	$password=$_POST['password'];
    
    $login= "select * from student_details where (username = '$username' and password='$password')";
    $results=mysqli_query($link,$login);
    $rowcount = mysqli_num_rows($results);
    if ($rowcount == 1) {
   
    header("location:/ci/index.php/home/dashb");
   
    }
    else
    {
    	 
    header("location:/ci/index.php/home/stdindex");
    }
   
 ?>
