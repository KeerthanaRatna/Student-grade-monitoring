<?php

$host="localhost"; // Host name.
    $db_user="root"; // MySQL username.
    $db_password=""; // MySQL password.
    $database="login"; // Database name.

  echo "YOUR REGISTRATION IS NOT COMPLETED...";
    $link = mysqli_connect($host,$db_user,$db_password,$database);

	
	$username = $_POST['username'];
	
	$password =  $_POST['password'];
	$query = "INSERT INTO teachers_details(username,password) VALUES ('$username','$password')";
	$data = mysqli_query ($link,$query) or die(mysql_error());
	if($data)
	{
	echo "YOUR REGISTRATION IS COMPLETED...";
	header("location:/ci/index.php/home/teaindex");
	}
	else{
		echo "YOUR REGISTRATION IS NOT COMPLETED...";
	}

?>
