<?php
    $host="localhost"; // Host name.
    $db_user="root"; // MySQL username.
    $db_password=""; // MySQL password.
    $database="login"; // Database name.
echo "user name and password not found";
  
    $link = mysqli_connect($host,$db_user,$db_password,$database);
    if (!$link) {
       die('Could not connect: ' . mysqli_error());
    }
     $username=$_POST['username'];
	$password=$_POST['password'];
    
    $login= "select * from teachers_details where (username = '$username' and password='$password')";
    $results=mysqli_query($link,$login);
    $rowcount = mysqli_num_rows($results);
    if ($rowcount == 1) {
    //$_SESSION[‘username’] =$username;
    header("location:/ci/index.php/home/dashb");
   
    }
    else
    {
    	 echo "user name and password not found";
    header("location:/ci/index.php/home/teaindex");
    }
   
 ?>
