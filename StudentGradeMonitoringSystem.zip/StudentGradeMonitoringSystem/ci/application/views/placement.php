<!DOCTYPE html>
<html>
<head>
    <title>Combo Bar-Line Chart</title>
    <script src="http://localhost/ci/assets/js/js/Chart.bundle.js"></script>
    <script src="http://localhost/ci/assets/js/js/utils.js"></script>
    <style>
    canvas {
        -moz-user-select: none;
        -webkit-user-select: none;
        -ms-user-select: none;
    }
    </style>
</head>

<body>
    <div style="width: 75%">
        <canvas id="mycanvas"></canvas>
    </div>
   
	
		<script type="text/javascript" src="http://localhost/ci/assets/js/js/jquery.min.js"></script>
		<script type="text/javascript" src="http://localhost/ci/assets/js/js/Chart.min.js"></script>
		<script type="text/javascript">
		
				
			var id = [];
			var term_1 = [];
			var term_2 = [];
			var term_3 = [];		
			var ctx = $("#mycanvas");
			var chartdata;
			var barGraphs;
			
			
			var randomColorGenerator = function () { 
			return '#' + (Math.random().toString(16) + '0000000').slice(2, 8); 
		};
		
		
			var color_1 = randomColorGenerator();
			var color_2 = randomColorGenerator();
			var color_3 = randomColorGenerator();



 var data =<?php echo json_encode($results) ?>;

 for(var i in data){
				id.push(data[i].Class);
				term_1.push(data[i].term_1);
				term_2.push(data[i].term_2);
				term_3.push(data[i].term_3);
				}
				
				
				
	 window.onload = function(){				
				window.barGraphs = new Chart(ctx, {
				type: 'line',
				data: chartdata,
				options: {
					responsive: true,
                    legend: {
                        position: 'top',
                    },
					title: {
                        display: true,
                        text: 'SELETED STUDENT CLASS POSITION VARIATION'
                    },
					scales: {
                    xAxes: [{
                        display: true,
                        scaleLabel: {
                            display: true,
                            labelString: 'CLASS'
                        }
                    }],
                    yAxes: [{
                        display: true,
                        scaleLabel: {
                            display: true,
                            labelString: 'POSITION OF THE CLASS'
                        }
                    }]
                }
										
					
				}
				
								
			});
			
	 };		
		
		
	chartdata = { 
				labels: id,
				datasets : [
					{	

						type: 'line', 
						data: term_1,
						fill:false,
						label: 'Term-1',
						backgroundColor: color_1,
						borderColor: color_1,
						borderWidth: 2,
					},
					
					{	

						type: 'line', 
						data:term_2,
						fill:false,
						label: 'Term-2',
						backgroundColor: color_2,
						borderColor: color_2,
						borderWidth: 2,
					},
					
					
					{	

						type: 'line', 
						data: term_3,
						fill:false,
						label:'Term-3',
						backgroundColor: color_3,
						borderColor: color_3,
						borderWidth: 2,
					},					
					

					
					
					
					
				]
			};
		
		
		</script>

	
</body>


</html>		
		
		
		