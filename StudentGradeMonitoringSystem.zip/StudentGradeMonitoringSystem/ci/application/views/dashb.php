<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="http://localhost/ci/assets/img/favicon.ico">		
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Student Grade Monitoring System</title>

    <style >
    body{

        background-image:url("http://localhost/ci/assets/img/header_bg.jpg");
    }

    </style>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="http://localhost/ci/assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="http://localhost/ci/assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="http://localhost/ci/assets/css/light-bootstrap-dashboard.css" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="http://localhost/ci/assets/css/demo.css" rel="stylesheet" />


    <!--     Fonts and icons     -->
    <link href="http://localhost/ci/assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="http://localhost/ci/assets/css/googlefont.css" rel='stylesheet' type='text/css'>
    <link href="http://localhost/ci/assets/css/pe-icon-7-stroke.css" rel="stylesheet" />

</head>
<body>

<div class="wrapper">
    <div class="sidebar" data-color="white" data-image="http://localhost/ci/assets/img/sidebar-8.jpg">

    <!--

        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag

    -->

    	<div class="sidebar-wrapper">
            <div class="logo">
                <a  class="simple-text">
                    <div><h2><b>Welcome</b></h2></div>
                    <div><h3><b>Student Grade Monitoring System</b></h3></div>  
                </a>
            </div>

            <ul class="nav">
                <li class="active">
                    <a href="dashb">
                        <i class="pe-7s-graph"></i>
                        <p><font size="3">Dashboard</font></p>
                    </a>
                </li>
                <li>
                    <a href="user">
                        <i class="pe-7s-user"></i>
                        <p><font size="3">User Profile</font></p>
                    </a>
                </li>                              
               
				<li>
                    <a href="browse">
                        <i class="pe-7s-upload"></i>
                        <p><font size="3">Upload Marks</font></p>
                    </a>
                </li>
				
            </ul>
    	</div>
    </div>

    <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    
                    <a class="navbar-brand" href="#">Dashboard</a>
                </div>
                <div class="collapse navbar-collapse">
                   

                    <ul class="nav navbar-nav navbar-right">
                        <li>
                           <a href="user">
                               Account
                            </a>
                        </li>
                        
						
                        <li>
                            <a href="started">
                                Log out
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>


						<div class="content">
							<div class="row">
								<form action="selectedStudent" method='post'  class="form-inline">
								
<table>	

		
		 <thead>
        <tr>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          
         
          
         
        </tr>
      </thead>						
					<tbody>	<tr>				
							<td>			<label><strong><h4><strong><font color="white"> SELECTED STUDENT GRAPHS :</font></strong></h4></strong></h5></label>
					
							</td>
							
							
									
										
								
									<div class="form-group">
							<td>			<label  for="index"><h5><strong><font color=" #66ccff" size="4">IndexNO</font></strong></h5></label>		
						
				
								
									<input id="index" name="index"  type="text" class="form-control">			
										
							</td>				
 									</div>
									                                     									
									
									<div class="form-group">
							<td>			<label  for="class" ><h5><strong><font color="66ccff" size="4">Grade</font></strong></h5></label>	</td>
							<td>				<div class="form-group">									
												<select name="grade" class="form-control" >
													<option value="Class6">Grade 6</option>
													<option value="Class7">Grade 7</option>
													<option value="Class8">Grade 8</option>
													<option value="Class9">Grade 9</option>
													<option value="Class10">Grade 10</option>
													<option value="Class11">Grade 11</option>									
												</select>
											</div>																			
							</td>																
											
 									</div>
									
								<td>
								</td>
								<td>
								</td>
									

									
									
									
							</div>	
								
							<td>			<button type="plot" class="btn btn-info btn-fill pull-right"><font color="white" size="4">Plot</button>		</td>
								 									
                                    <div class="clearfix"></div>
									 
								</form>	
                                     
							</tr>
                        
		
						
						
						
							<div class="row">
					<tr>			<form action="subject" method="post"  class="form-inline">
								
								
									
					<td>					<label><strong><h4><strong><font color="white">SELECTED SUBJECT GRAPHS :</font></strong></h4></strong></h5></label>		</td>
									
										
								
									<div class="form-group">
					<td>				
										<label  for="index"><h5><strong><font color="66ccff" size="4">IndexNo</font></strong></h5></label>
																															
												<input id="index" name="index"  type="text" class="form-control">										
					</td>						
 									</div>
									                                     									
									
									<div class="form-group">
					<td>					<label  for="subject" ><h5><strong><font color="66ccff" size="4">Subject</font></strong></h5></label>		</td>
											<div class="form-group">									
					<td>							<select name="subject" class="form-control" >
													<option value="Maths">Maths</option>
													<option value="Science">Science</option>
													<option value="English">English</option>
													<option value="Language">Language</option>
													<option value="Religon">Religon</option>
													<option value="History">History</option>									
													<option value="Average">Avarage</option>									
																						
												</select>
											</div>																			
					</td>																		
											<td>
								</td>
								<td>
								</td>
 									
									
									
									
							</div>	
								
					<td>					<button type="plot" class="btn btn-info btn-fill pull-right"><font color="white" size="4">Plot<font></button>		</td>
								 									
                                    <div class="clearfix"></div>
									 
								</form>	
						
					</tr>	





					

							
				<tr>			
								
								
								<div class="row">
								<form action="placement" method="post"  class="form-inline">
								
								
									
				<td>						<label><strong><h4><strong><font color="white">PLACEMENT GRAPHS :</font></strong></h4></strong></h5></label>		</td>
									
										
								
									<div class="form-group">
				<td>						<label  for="index"><strong><font color="66ccff" size="4">IndexNo</font></strong></label>
																															
												<input id="index" name="index"  type="text" class="form-control">										
				</td>							
 									</div>
									                                     									
				
				
									
				</td>					
				
									
								
								
									
									
							</div>	
							<td>
							</td>
							<td>
							</td>
							<td>
								</td>
								<td>
								</td>
								
								
				<td>						<button type="plot" class="btn btn-info btn-fill pull-right"><font color="white" size="4">Plot</font></button>		</td>
								 									
                                    <div class="clearfix"></div>
									 
								</form>	
								
				</tr>				
								 
				<tr>	
							<div class="row">
								<form action="class1" method="post"  class="form-inline">
								
								
									
					<td>					<label><strong><h4><strong><font color="white">SELECTED CLASS GRAPHS :</font></strong></h4></strong></h5></label>			</td>
									
										
								
									<div class="form-group">
					<td>				
										<label  for="index"><h5><strong><font color="66ccff" size="4">Year   </font></strong></h5></label>
						
							
												<input id="year" name="year"  type="text" class="form-control">												
					</td>						
 									</div>
									                                     									
									
									<div class="form-group">
					<td>					<label  for="class" ><h5><strong><font color="66ccff" size="4">Grade</font></strong></h5></label>	</td>
					<td>						<div class="form-group">									
												<select name="grade" class="form-control" >
													<option value="6">Grade 6</option>
													<option value="7">Grade 7</option>
													<option value="8">Grade 8</option>
													<option value="9">Grade 9</option>
													<option value="10">Grade 10</option>
													<option value="11">Grade 11</option>									
												</select>
											</div>																			
					</td>																		
											
 									</div>
									
									
									<div class="form-group">
					<td>					<label  for="term" ><h5><strong><font color="66ccff" size="4">Term</font></strong></h5></label>
					
											<div class="form-group">									
												<select name= "term" class="form-control" >
													<option value ="1">Term 1</option>
													<option value ="2">Term 2</option>
													<option value ="3">Term 3</option>
													<option value ="Average">Average</option>																					
												</select>
											</div>																			
					</td>								
						<td>
						</td>
											
 									</div>
									
									
							</div>	
							
					<td>					<button type="plot" class="btn btn-info btn-fill pull-right"><font color="white" size="4">Plot</font></button>		</td>
								 									
                                    <div class="clearfix"></div>
									 
								</form>	
                                 


					</tr>			 			
                        

				<tr>
						<div class="row">
								<form action="comparing" method="post"  class="form-inline">
								
								
									
				<td>						<label><strong><h4><strong><font color="white">COMPARING TWO BATCHES :</font></strong></h4></strong></label>		</td>
									
										
								
									<div class="form-group">
				<td>						<label  for="index"><h5><strong><font color="66ccff" size="4">Year </font></strong></h5></label>
																															
												<input id="year1" name="year1"  type="text" class="form-control">												
				</td>							
 									</div>
				

									<div class="form-group">
				<td>						<label  for="index"><h5><strong><font color="66ccff" size="4">Year</font></strong></h5></label>		</td>
				<td>																											
												<input id="year1" name="year2"  type="text" class="form-control">												
				</td>							
 									</div>	
				

				
									<div class="form-group">
				<td>						<label  for="class" ><h5><strong><font color="66ccff" size="4">Grade</font></strong></h5></label>	
											<div class="form-group">									
												<select name="grade" class="form-control" >
													<option value="Class6">Grade 6</option>
													<option value="Class7">Grade 7</option>
													<option value="Class8">Grade 8</option>
													<option value="Class9">Grade 9</option>
													<option value="Class10">Grade 10</option>
													<option value="Class11">Grade 11</option>									
												</select>
											</div>																			
				</td>																			
											
 									</div>
									
								
				
									
							</div>	
							<div class="form-group">
					<td>					<label  for="term" ><h5><strong><font color="66ccff" size="4">Term</font></strong></h5></label>
											<div class="form-group">									
												<select name= "term" class="form-control" >
													<option value ="1">Term 1</option>
													<option value ="2">Term 2</option>
													<option value ="3">Term 3</option>
													
												</select>
											</div>	
								
				<td>						<button type="plot" class="btn btn-info btn-fill pull-right"><font color="white" size="4">Plot<font></button>		</td>
								 									
                                    <div class="clearfix"></div>
									 
								</form>	
                </tr>

			</tbody>
</table>				
</div>


</body>

    <!--   Core JS Files   -->
    <script src="http://localhost/ci/assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="http://localhost/ci/assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="http://localhost/ci/assets/js/bootstrap-checkbox-radio-switch.js"></script>

	<!--  Charts Plugin -->
	<script src="http://localhost/ci/assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="http://localhost/ci/assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
   
    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="http://localhost/ci/assets/js/light-bootstrap-dashboard.js"></script>

	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
	<script src="http://localhost/ci/assets/js/demo.js"></script>

	<script type="text/javascript">
    	$(document).ready(function(){

        	demo.initChartist();

        	$.notify({
            	icon: 'pe-7s-gift',
            	message: "Welcome to <b>STUDENDT GRADE MONITERING SYSTEM</b> - Short Semester project"

            },{
                type: 'info',
                timer: 4000
            });

    	});
	</script>

</html>
