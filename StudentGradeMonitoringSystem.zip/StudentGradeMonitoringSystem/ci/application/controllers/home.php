<?php


class Home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 */
	

	public function started()
	{
		$this->load->view('started');
		
		
	}
	
	public function teaindex()
	{
		$this->load->view('teaindex');
		
		
	}
	public function browse()
	{
		$this->load->view('browse');
		
		
	}
	public function selectedStudent(){
			
		  $p = $this->input->post();
        if($p){
		
	
		$index=$this->input->post("index");
	
		$this->load->model('HomeModel');
		//$this->HomeModel->getData();


define('DB_HOST','localhost');
define('DB_uNAME','root');
define('DB_PASSWORD','');
define('DB_NAME','csv');

$mysqli = new mysqli(DB_HOST,DB_uNAME,DB_PASSWORD,DB_NAME);

if(!$mysqli){
  die("Connection failed:");
}

if ($this->input->post("index") <100) {

switch($this->input->post("grade")){
case 'Class6':

 $query ="( SELECT English,Religion,Science,History,Language,Maths FROM gr6_1_2010_OL WHERE indexno=$index)
 UNION ( SELECT English,Religion,Science,History,Language,Maths FROM gr6_2_2010_OL WHERE indexno=$index)
 UNION ( SELECT English,Religion,Science,History,Language,Maths FROM gr6_3_2010_OL WHERE indexno=$index)" ;

  break;  

  case 'Class7':

 $query ="( SELECT English,Religion,Science,History,Language,Maths FROM gr6_1_2010_OL WHERE indexno=$index)
 UNION ( SELECT English,Religion,Science,History,Language,Maths FROM gr6_2_2010_OL WHERE indexno=$index)
 UNION ( SELECT English,Religion,Science,History,Language,Maths FROM gr6_3_2010_OL WHERE indexno=$index)" ;
  break; 

  case 'Class8':

 $query ="( SELECT English,Religion,Science,History,Language,Maths FROM gr6_1_2010_OL WHERE indexno=$index)
 UNION ( SELECT English,Religion,Science,History,Language,Maths FROM gr6_2_2010_OL WHERE indexno=$index)
 UNION ( SELECT English,Religion,Science,History,Language,Maths FROM gr6_3_2010_OL WHERE indexno=$index)" ;
  break; 

  case 'Class9':

 $query ="( SELECT English,Religion,Science,History,Language,Maths FROM gr6_1_2010_OL WHERE indexno=$index)
 UNION ( SELECT English,Religion,Science,History,Language,Maths FROM gr6_2_2010_OL WHERE indexno=$index)
 UNION ( SELECT English,Religion,Science,History,Language,Maths FROM gr6_3_2010_OL WHERE indexno=$index)" ;
break;
  case 'Class10':

 $query ="( SELECT English,Religion,Science,History,Language,Maths FROM gr6_1_2010_OL WHERE indexno=$index)
 UNION ( SELECT English,Religion,Science,History,Language,Maths FROM gr6_2_2010_OL WHERE indexno=$index)
 UNION ( SELECT English,Religion,Science,History,Language,Maths FROM gr6_3_2010_OL WHERE indexno=$index)" ;  break; 

  case 'Class11':

 $query ="( SELECT English,Religion,Science,History,Language,Maths FROM gr6_1_2010_OL WHERE indexno=$index)
 UNION ( SELECT English,Religion,Science,History,Language,Maths FROM gr6_2_2010_OL WHERE indexno=$index)
 UNION ( SELECT English,Religion,Science,History,Language,Maths FROM gr6_3_2010_OL WHERE indexno=$index)" ;
  break; 
   
}
}
if($this->input->post("index") >100){
	switch($this->input->post("grade")){
case 'Class6':

 $query ="( SELECT English,Religion,Science,History,Language,Maths FROM gr6_1_2011_OL WHERE indexno=$index)
 UNION ( SELECT English,Religion,Science,History,Language,Maths FROM gr6_2_2011_OL WHERE indexno=$index)
 UNION ( SELECT English,Religion,Science,History,Language,Maths FROM gr6_3_2011_OL WHERE indexno=$index)" ;

  break;  

  case 'Class7':

 $query ="( SELECT English,Religion,Science,History,Language,Maths FROM gr6_1_2011_OL WHERE indexno=$index)
 UNION ( SELECT English,Religion,Science,History,Language,Maths FROM gr6_2_2011_OL WHERE indexno=$index)
 UNION ( SELECT English,Religion,Science,History,Language,Maths FROM gr6_3_2011_OL WHERE indexno=$index)" ;
  break; 

  case 'Class8':

 $query ="( SELECT English,Religion,Science,History,Language,Maths FROM gr6_1_2011_OL WHERE indexno=$index)
 UNION ( SELECT English,Religion,Science,History,Language,Maths FROM gr6_2_2011_OL WHERE indexno=$index)
 UNION ( SELECT English,Religion,Science,History,Language,Maths FROM gr6_3_2011_OL WHERE indexno=$index)" ;
  break; 

  case 'Class9':

 $query ="( SELECT English,Religion,Science,History,Language,Maths FROM gr6_1_2011_OL WHERE indexno=$index)
 UNION ( SELECT English,Religion,Science,History,Language,Maths FROM gr6_2_2011_OL WHERE indexno=$index)
 UNION ( SELECT English,Religion,Science,History,Language,Maths FROM gr6_3_2011_OL WHERE indexno=$index)" ;
break;
  case 'Class10':

 $query ="( SELECT English,Religion,Science,History,Language,Maths FROM gr6_1_2011_OL WHERE indexno=$index)
 UNION ( SELECT English,Religion,Science,History,Language,Maths FROM gr6_2_2011_OL WHERE indexno=$index)
 UNION ( SELECT English,Religion,Science,History,Language,Maths FROM gr6_3_2011_OL WHERE indexno=$index)" ;  break; 

  case 'Class11':

 $query ="( SELECT English,Religion,Science,History,Language,Maths FROM gr6_1_2011_OL WHERE indexno=$index)
 UNION ( SELECT English,Religion,Science,History,Language,Maths FROM gr6_2_2011_OL WHERE indexno=$index)
 UNION ( SELECT English,Religion,Science,History,Language,Maths FROM gr6_3_2011_OL WHERE indexno=$index)" ;
  break; 
   
}

}


$result =mysqli_query($mysqli,$query);

$data = array();
 while($row =mysqli_fetch_assoc($result))
    {
        $data[] = $row;
    }


mysqli_close($mysqli);


	$array1['results']=$data;

	$this->load->view('selectedStudent',$array1);
	}


}
	public function subject(){
		
		
		
		  $p = $this->input->post();
        if($p){
		
		$this->load->view('subject',$p);
	}
}


public function placement(){
		
		
		
		  $p = $this->input->post();
        if($p){
		$index=$this->input->post("index");
	
		$this->load->model('HomeModel');
        	
//header('content-Type: application/json');

define('DB_HOST','localhost');
define('DB_uNAME','root');
define('DB_PASSWORD','');
define('DB_NAME','csv');

$mysqli = new mysqli(DB_HOST,DB_uNAME,DB_PASSWORD,DB_NAME);

if(!$mysqli){
	die("Connection failed:");
}
if($this->input->post("index") <100){

$query ="(SELECT a.Grade as Class,FIND_IN_SET( a.indexno, (
SELECT GROUP_CONCAT( a.indexno
ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) 
FROM gr6_1_2010_OL as a)
) AS term_1,FIND_IN_SET( b.indexno, (
SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr6_2_2010_OL as b)
) AS term_2 ,FIND_IN_SET( c.indexno, (
SELECT GROUP_CONCAT( c.indexno
ORDER BY (c.English+c.Religion+c.Science+c.History+c.Language+c.Maths+c.buck1+c.buck2+c.buck3)/9 DESC ) 
FROM gr6_3_2010_OL as c)
) AS term_3 FROM gr6_1_2010_OL as a,gr6_2_2010_OL as b,gr6_3_2010_OL as c WHERE (a.indexno=$index) AND (b.indexno=$index) AND (c.indexno=$index))
UNION 
(SELECT a.Grade as Class,FIND_IN_SET( a.indexno, (
SELECT GROUP_CONCAT( a.indexno
ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) 
FROM gr7_1_2010_OL as a)
) AS term_1,FIND_IN_SET( b.indexno, (
SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr7_2_2010_OL as b)
) AS term_2 ,FIND_IN_SET( c.indexno, (
SELECT GROUP_CONCAT( c.indexno
ORDER BY (c.English+c.Religion+c.Science+c.History+c.Language+c.Maths+c.buck1+c.buck2+c.buck3)/9 DESC ) 
FROM gr7_3_2010_OL as c)
) AS term_3 FROM gr7_1_2010_OL as a,gr7_2_2010_OL as b,gr7_3_2010_OL as c WHERE (a.indexno=$index) AND (b.indexno=$index) AND (c.indexno=$index))
UNION 
(SELECT a.Grade as Class,FIND_IN_SET( a.indexno, (
SELECT GROUP_CONCAT( a.indexno
ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) 
FROM gr8_1_2010_OL as a)
) AS term_1,FIND_IN_SET( b.indexno, (
SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr8_2_2010_OL as b)
) AS term_2 ,FIND_IN_SET( c.indexno, (
SELECT GROUP_CONCAT( c.indexno
ORDER BY (c.English+c.Religion+c.Science+c.History+c.Language+c.Maths+c.buck1+c.buck2+c.buck3)/9 DESC ) 
FROM gr8_3_2010_OL as c)
) AS term_3 FROM gr8_1_2010_OL as a,gr8_2_2010_OL as b,gr8_3_2010_OL as c WHERE (a.indexno=$index) AND (b.indexno=$index) AND (c.indexno=$index))
UNION 
(SELECT a.Grade as Class,FIND_IN_SET( a.indexno, (
SELECT GROUP_CONCAT( a.indexno
ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) 
FROM gr9_1_2010_OL as a)
) AS term_1,FIND_IN_SET( b.indexno, (
SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr9_2_2010_OL as b)
) AS term_2 ,FIND_IN_SET( c.indexno, (
SELECT GROUP_CONCAT( c.indexno
ORDER BY (c.English+c.Religion+c.Science+c.History+c.Language+c.Maths+c.buck1+c.buck2+c.buck3)/9 DESC ) 
FROM gr9_3_2010_OL as c)
) AS term_3 FROM gr9_1_2010_OL as a,gr9_2_2010_OL as b,gr9_3_2010_OL as c WHERE (a.indexno=$index) AND (b.indexno=$index) AND (c.indexno=$index))
UNION 
(SELECT a.Grade as Class,FIND_IN_SET( a.indexno, (
SELECT GROUP_CONCAT( a.indexno
ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) 
FROM gr10_1_2010_OL as a)
) AS term_1,FIND_IN_SET( b.indexno, (
SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr10_2_2010_OL as b)
) AS term_2 ,FIND_IN_SET( c.indexno, (
SELECT GROUP_CONCAT( c.indexno
ORDER BY (c.English+c.Religion+c.Science+c.History+c.Language+c.Maths+c.buck1+c.buck2+c.buck3)/9 DESC ) 
FROM gr10_3_2010_OL as c)
) AS term_3 FROM gr10_1_2010_OL as a,gr10_2_2010_OL as b,gr10_3_2010_OL as c WHERE (a.indexno=$index) AND (b.indexno=$index) AND (c.indexno=$index))
UNION 
(SELECT a.Grade as Class,FIND_IN_SET( a.indexno, (
SELECT GROUP_CONCAT( a.indexno
ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) 
FROM gr11_1_2010_OL as a)
) AS term_1,FIND_IN_SET( b.indexno, (
SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr11_2_2010_OL as b)
) AS term_2 ,FIND_IN_SET( c.indexno, (
SELECT GROUP_CONCAT( c.indexno
ORDER BY (c.English+c.Religion+c.Science+c.History+c.Language+c.Maths+c.buck1+c.buck2+c.buck3)/9 DESC ) 
FROM gr11_3_2010_OL as c)
) AS term_3 FROM gr11_1_2010_OL as a,gr11_2_2010_OL as b,gr11_3_2010_OL as c WHERE (a.indexno=$index) AND (b.indexno=$index) AND (c.indexno=$index))
";	
}		

if($this->input->post("index") >100){

$query ="(SELECT a.Grade as Class,FIND_IN_SET( a.indexno, (
SELECT GROUP_CONCAT( a.indexno
ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) 
FROM gr6_1_2011_ol as a)
) AS term_1,FIND_IN_SET( b.indexno, (
SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr6_2_2011_ol as b)
) AS term_2 ,FIND_IN_SET( c.indexno, (
SELECT GROUP_CONCAT( c.indexno
ORDER BY (c.English+c.Religion+c.Science+c.History+c.Language+c.Maths+c.buck1+c.buck2+c.buck3)/9 DESC ) 
FROM gr6_3_2011_ol as c)
) AS term_3 FROM gr6_1_2011_ol as a,gr6_2_2011_ol as b,gr6_3_2011_ol as c WHERE (a.indexno=$index) AND (b.indexno=$index) AND (c.indexno=$index))
UNION 
(SELECT a.Grade as Class,FIND_IN_SET( a.indexno, (
SELECT GROUP_CONCAT( a.indexno
ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) 
FROM gr7_1_2011_ol as a)
) AS term_1,FIND_IN_SET( b.indexno, (
SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr7_2_2011_ol as b)
) AS term_2 ,FIND_IN_SET( c.indexno, (
SELECT GROUP_CONCAT( c.indexno
ORDER BY (c.English+c.Religion+c.Science+c.History+c.Language+c.Maths+c.buck1+c.buck2+c.buck3)/9 DESC ) 
FROM gr7_3_2011_ol as c)
) AS term_3 FROM gr7_1_2011_ol as a,gr7_2_2011_ol as b,gr7_3_2011_ol as c WHERE (a.indexno=$index) AND (b.indexno=$index) AND (c.indexno=$index))
UNION 
(SELECT a.Grade as Class,FIND_IN_SET( a.indexno, (
SELECT GROUP_CONCAT( a.indexno
ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) 
FROM gr8_1_2011_ol as a)
) AS term_1,FIND_IN_SET( b.indexno, (
SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr8_2_2011_ol as b)
) AS term_2 ,FIND_IN_SET( c.indexno, (
SELECT GROUP_CONCAT( c.indexno
ORDER BY (c.English+c.Religion+c.Science+c.History+c.Language+c.Maths+c.buck1+c.buck2+c.buck3)/9 DESC ) 
FROM gr8_3_2011_ol as c)
) AS term_3 FROM gr8_1_2011_ol as a,gr8_2_2011_ol as b,gr8_3_2011_ol as c WHERE (a.indexno=$index) AND (b.indexno=$index) AND (c.indexno=$index))
UNION 
(SELECT a.Grade as Class,FIND_IN_SET( a.indexno, (
SELECT GROUP_CONCAT( a.indexno
ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) 
FROM gr9_1_2011_ol as a)
) AS term_1,FIND_IN_SET( b.indexno, (
SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr9_2_2011_ol as b)
) AS term_2 ,FIND_IN_SET( c.indexno, (
SELECT GROUP_CONCAT( c.indexno
ORDER BY (c.English+c.Religion+c.Science+c.History+c.Language+c.Maths+c.buck1+c.buck2+c.buck3)/9 DESC ) 
FROM gr9_3_2011_ol as c)
) AS term_3 FROM gr9_1_2011_ol as a,gr9_2_2011_ol as b,gr9_3_2011_ol as c WHERE (a.indexno=$index) AND (b.indexno=$index) AND (c.indexno=$index))
UNION 
(SELECT a.Grade as Class,FIND_IN_SET( a.indexno, (
SELECT GROUP_CONCAT( a.indexno
ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) 
FROM gr10_1_2011_ol as a)
) AS term_1,FIND_IN_SET( b.indexno, (
SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr10_2_2011_ol as b)
) AS term_2 ,FIND_IN_SET( c.indexno, (
SELECT GROUP_CONCAT( c.indexno
ORDER BY (c.English+c.Religion+c.Science+c.History+c.Language+c.Maths+c.buck1+c.buck2+c.buck3)/9 DESC ) 
FROM gr10_3_2011_ol as c)
) AS term_3 FROM gr10_1_2011_ol as a,gr10_2_2011_ol as b,gr10_3_2011_ol as c WHERE (a.indexno=$index) AND (b.indexno=$index) AND (c.indexno=$index))
UNION 
(SELECT a.Grade as Class,FIND_IN_SET( a.indexno, (
SELECT GROUP_CONCAT( a.indexno
ORDER BY (a.English+a.Religion+a.Science+a.History+a.Language+a.Maths+a.buck1+a.buck2+a.buck3)/9 DESC ) 
FROM gr11_1_2011_ol as a)
) AS term_1,FIND_IN_SET( b.indexno, (
SELECT GROUP_CONCAT( b.indexno
ORDER BY (b.English+b.Religion+b.Science+b.History+b.Language+b.Maths+b.buck1+b.buck2+b.buck3)/9 DESC ) 
FROM gr11_2_2011_ol as b)
) AS term_2 ,FIND_IN_SET( c.indexno, (
SELECT GROUP_CONCAT( c.indexno
ORDER BY (c.English+c.Religion+c.Science+c.History+c.Language+c.Maths+c.buck1+c.buck2+c.buck3)/9 DESC ) 
FROM gr11_3_2011_ol as c)
) AS term_3 FROM gr11_1_2011_ol as a,gr11_2_2011_ol as b,gr11_3_2011_ol as c WHERE (a.indexno=$index) AND (b.indexno=$index) AND (c.indexno=$index))
";	
}


$result =mysqli_query($mysqli,$query);

$data = array();
 while($row =mysqli_fetch_assoc($result))
    {
        $data[] = $row;
    }


mysqli_close($mysqli);


$array1['results']=$data;
	
 
	$this->load->view('placement',$array1);

 
	}
}

public function class1(){
		
		
		
		  $p = $this->input->post();
        if($p){
		

        	$index=$this->input->post("index");
        	$grade=$this->input->post("grade");
        	$term=$this->input->post("term");
        	$year=$this->input->post("year");

define('DB_HOST','localhost');
define('DB_uNAME','root');
define('DB_PASSWORD','');
define('DB_NAME','csv');

$mysqli = new mysqli(DB_HOST,DB_uNAME,DB_PASSWORD,DB_NAME);

if(!$mysqli){
	die("Connection failed:");
}
if($this->input->post("year") == 2010){
 
switch($this->input->post("grade")){
	case '6':
$query =" (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr6_1_2010_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) UNION (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr6_2_2010_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) UNION (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr6_3_2010_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) " ;
break;

case '7':
$query =" (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr7_1_2010_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) UNION (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr7_2_2010_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) UNION (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr7_3_2010_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) " ;
break;

case '8':
$query =" (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr8_1_2010_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) UNION (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr8_2_2010_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term) )UNION (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr8_3_2010_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) " ;
break;

case '9':
$query =" (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr9_1_2010_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) UNION (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr9_2_2010_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) UNION (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr9_3_2010_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) " ;
break;

case '10':
$query =" (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr10_1_2010_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) UNION (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr10_2_2010_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) UNION (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr10_3_2010_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) " ;
break;

case '11':
$query =" (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr11_1_2010_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) UNION (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr11_2_2010_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) UNION (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr11_3_2010_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) " ;
break;
}
}
if($this->input->post("year") == 2011){
switch($this->input->post("grade")){
	case '6':
$query =" (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr6_1_2011_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) UNION (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr6_2_2011_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) UNION (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr6_3_2011_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) " ;
break;

case '7':
$query =" (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr7_1_2011_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) UNION (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr7_2_2011_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) UNION (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr7_3_2011_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) " ;
break;

case '8':
$query =" (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr8_1_2011_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) UNION (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr8_2_2011_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term) )UNION (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr8_3_2011_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) " ;
break;

case '9':
$query =" (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr9_1_2011_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) UNION (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr9_2_2011_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) UNION (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr9_3_2011_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) " ;
break;

case '10':
$query =" (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr10_1_2011_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) UNION (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr10_2_2011_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) UNION (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr10_3_2011_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) " ;
break;

case '11':
$query =" (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr11_1_2011_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) UNION (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr11_2_2011_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) UNION (SELECT indexno,English,Religion,Science,History,Language,Maths  FROM gr11_3_2011_OL   WHERE (year=$year) AND (Grade=$grade) AND (Term=$term)) " ;
break;
}
	}

$result =mysqli_query($mysqli,$query);

$data = array();
 while($row =mysqli_fetch_assoc($result))
    {
        $data[] = $row;
    }



mysqli_close($mysqli);


$array1['results']=$data;

$this->load->view('class1',$array1);

	}
}

public function comparing(){
		
		
		
		  $p = $this->input->post();
        if($p){
		
		$this->load->view('comparing',$p);
	}
}



	public function stdindex()
	{
		$this->load->view('stdindex');
		
		
	}
	
	
	
	public function dashb()
	{
		$this->load->view('dashb');
		
		
	}
	
	
	
	public function user()
	{
		$this->load->view('user');
		
		
	}
	
	public function login_connect_db()
	{
		 $p = $this->input->post();
      
		
		$this->load->view('login_connect_db',$p);
		

	}
	public function teacher_login_db()
	{
		 $p = $this->input->post();
      
		
		$this->load->view('teacher_login_db',$p);
		

	}
	
	public function signup()
	{
		 $p = $this->input->post();
      
		
		$this->load->view('signup',$p);
		

	}
	public function techer_signup()
	{
		 $p = $this->input->post();
      
		
		$this->load->view('techer_signup',$p);
		

	}
	
}
