$(document).ready(function(){
	
			var id = [];
			var maths_mark = [];
			var science_mark = [];
			var english_mark = [];
			var language_mark = [];
			var ctx = $("#mycanvas");
			var chartdata;
			var barGraphs;
			var color_1;
			var color_2;
			var color_3;
			var color_4;
			
			
			
			var randomColorGenerator = function () { 
			return '#' + (Math.random().toString(16) + '0000000').slice(2, 8); 
		};
			
			
			color_1 = randomColorGenerator();
			color_2 = randomColorGenerator();
			color_3 = randomColorGenerator();
			color_4 = randomColorGenerator();
			
	$.ajax({
		url: "subject_graphs.json",
		dataType:"json",
		
		success: function(data) {
			console.log(data);
		


			
			for(var i in data){
				id.push(data[i].Class);
				maths_mark.push(data[i].Term_1);
				science_mark.push(data[i].Term_2);
				english_mark.push(data[i].Term_3);
				language_mark.push(data[i].Average);
				
			}


			 barGraphs = new Chart(ctx, {
				type: 'line',
				data: chartdata,
				options: {
					responsive: true,
                    legend: {
                        position: 'top',
                    },
					title: {
                        display: true,
                        text: 'SELECTED STUDENT SELECTED SUBJECT MARKS VARIATION'
                    },
					scales: {
                    xAxes: [{
                        display: true,
                        scaleLabel: {
                            display: true,
                            labelString: 'CLASS'
                        }
                    }],
                    yAxes: [{
                        display: true,
                        scaleLabel: {
                            display: true,
                            labelString: 'MARK'
                        }
                    }]
                }
										
					
				}
				
								
			});
														
			
		},
		error: function(data) {
			console.log(data);
		}
	});
	

	chartdata = { 
				labels: id,
				datasets : [
					{	

						type: 'line', 
						data: maths_mark,
						fill:false,
						label: 'Term-1',
						backgroundColor: color_1,
						borderColor: color_1,
						borderWidth: 2,
					},
					
					{	

						type: 'line', 
						data:science_mark,
						fill:false,
						label: 'Term-2',
						backgroundColor: color_4,
						borderColor: color_4,
						borderWidth: 2,
					},
					
					
					{	

						type: 'line', 
						data: english_mark,
						fill:false,
						label:'Term-3',
						backgroundColor: color_2,
						borderColor: color_2,
						borderWidth: 2,
					},					
					{	

						type: 'line', 
						data: language_mark,
						fill:false,
						label: 'Average of the year',
						backgroundColor: color_3,
						borderColor: color_3,
						borderWidth: 2,
					},

					
					
					
					
				]
			}
				
				
			
			;
		
});