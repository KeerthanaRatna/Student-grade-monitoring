$(document).ready(function(){
	
			var id = [];
			var term_1 = [];
			var term_2 = [];
			var term_3 = [];
			
			var ctx = $("#mycanvas");
			var chartdata;
			var barGraphs;
			
			
			
			var randomColorGenerator = function () { 
			return '#' + (Math.random().toString(16) + '0000000').slice(2, 8); 
		};
			
			
	$.ajax({
		url: "placement_graphs.json",
		dataType:"json",
		
		success: function(data) {
			console.log(data);
		


			
			
				for(var i in data){
				id.push(data[i].Class);
				term_1.push(data[i].Term_1);
				term_2.push(data[i].Term_2);
				term_3.push(data[i].Term_3);
								
			}
				
				
		


			 barGraphs = new Chart(ctx, {
				type: 'line',
				data: chartdata,
				options: {
					responsive: true,
                    legend: {
                        position: 'top',
                    },
					title: {
                        display: true,
                        text: 'SELETED STUDENT CLASS POSITION VARIATION'
                    },
					scales: {
                    xAxes: [{
                        display: true,
                        scaleLabel: {
                            display: true,
                            labelString: 'CLASS'
                        }
                    }],
                    yAxes: [{
                        display: true,
                        scaleLabel: {
                            display: true,
                            labelString: 'POSITION OF THE CLASS'
                        }
                    }]
                }
										
					
				}
				
								
			});
														
			
		},
		error: function(data) {
			console.log(data);
		}
	});
	

	chartdata = { 
				labels: id,
				datasets : [
					{	

						type: 'line', 
						data: term_1,
						fill:false,
						label: 'Term-1',
						backgroundColor: randomColorGenerator(),
						borderColor: randomColorGenerator(),
						borderWidth: 2,
					},
					
					{	

						type: 'line', 
						data:term_2,
						fill:false,
						label: 'Term-2',
						backgroundColor: randomColorGenerator(),
						borderColor: randomColorGenerator(),
						borderWidth: 2,
					},
					
					
					{	

						type: 'line', 
						data: term_3,
						fill:false,
						label:'Term-3',
						backgroundColor: randomColorGenerator(),
						borderColor: randomColorGenerator(),
						borderWidth: 2,
					},					
					

					
					
					
					
				]
			}
				
				
			
			;
		
});