$(document).ready(function(){
	
			var id = [];
			var maths_mark = [];
			var science_mark = [];
			var english_mark = [];
			var language_mark = [];
			var religon_mark = [];
			var history_mark = [];
			var ctx = $("#mycanvas");
			var chartdata;
			var barGraphs;
			var type = 'bar';
			
			
			var randomColorGenerator = function () { 
			return '#' + (Math.random().toString(16) + '0000000').slice(2, 8); 
		};
			
			
	$.ajax({
		url: "class_graphs.json",
		dataType:"json",
		
		success: function(data) {
			console.log(data);
		


			
			for(var i in data){
				id.push(data[i].id);
				maths_mark.push(data[i].Maths);
				science_mark.push(data[i].Science);
				english_mark.push(data[i].English);
				language_mark.push(data[i].Language);
				religon_mark.push(data[i].Religon);
				history_mark.push(data[i].History);
			}


			 barGraphs = new Chart(ctx, {
				type: 'bar',
				data: chartdata,
				options: {
					responsive: true,
                    legend: {
                        position: 'top',
                    },
					title: {
                        display: true,
                        text: 'SELECTED CLASS ALL SUBJETS MARKS ANALYSE'
                    },
					scales: {
                    xAxes: [{
                        display: true,
                        scaleLabel: {
                            display: true,
                            labelString: 'INDEX NUMBER'
                        }
                    }],
                    yAxes: [{
                        display: true,
                        scaleLabel: {
                            display: true,
                            labelString: 'MARK'
                        }
                    }]
                }
										
					
				}
				
								
			});
														
			
		},
		error: function(data) {
			console.log(data);
		}
	});
	

	chartdata = { 
				labels: id,
				datasets : [
					{	

						type: 'line', 
						data: maths_mark,
						fill:false,
						label: 'Maths mark line graph',
						backgroundColor: randomColorGenerator(),
						borderColor: randomColorGenerator(),
						borderWidth: 2,
					},
					{	

						type: 'bar', 
						data: maths_mark,
						label: 'Maths mark bar graph',
						backgroundColor: randomColorGenerator(),												
					},
					{	

						type: 'line', 
						data:science_mark,
						fill:false,
						label: 'science mark line graph',
						backgroundColor: randomColorGenerator(),
						borderColor: randomColorGenerator(),
						borderWidth: 2,
					},
					{	

						type: 'bar', 
						data: science_mark,
						label: 'Science mark bar graph',
						backgroundColor: randomColorGenerator(),												
					},
					
					{	

						type: 'line', 
						data: english_mark,
						fill:false,
						label:'English subject mark',
						backgroundColor: randomColorGenerator(),
						borderColor: randomColorGenerator(),
						borderWidth: 2,
					},
					{		

						type: 'bar', 
						data: english_mark,
						label: 'English mark bar graph',
						backgroundColor: randomColorGenerator(),												
					},
					{	

						type: 'line', 
						data: language_mark,
						fill:false,
						label: 'Language mark line graph',
						backgroundColor: randomColorGenerator(),
						borderColor: randomColorGenerator(),
						borderWidth: 2,
					},
					{	

						type: 'bar', 
						data: language_mark,
						label: 'Language mark bar graph',
						backgroundColor: randomColorGenerator(),												
					},
					{	

						type: 'line', 
						data: religon_mark,
						fill:false,
						label: 'Religon mark line graph',
						backgroundColor: randomColorGenerator(),
						borderColor: randomColorGenerator(),
						borderWidth: 2,
					},	
					{	

						type: 'bar', 
						data: religon_mark,
						label: 'Religon mark bar graph',
						backgroundColor: randomColorGenerator(),												
					},
					{	

						type: 'line', 
						data: history_mark,
						fill:false,
						label: 'History mark line graph',
						backgroundColor: randomColorGenerator(),
						borderColor: randomColorGenerator(),
						borderWidth: 2,
					},
					{	

						type: 'bar', 
						data: history_mark,
						label: 'History mark bar graph',
						backgroundColor: randomColorGenerator(),												
					}
					
					
					
				]
			}
				
				
			
			;
		
});