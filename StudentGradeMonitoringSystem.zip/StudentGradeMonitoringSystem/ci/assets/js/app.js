$(document).ready(function(){
	
			var player = [];
			var score = [];
			var ctx = $("#mycanvas");
			var chartdata;
			var barGraph;
			var type = 'bar';
			
			
			var randomColorGenerator = function () { 
			return '#' + (Math.random().toString(16) + '0000000').slice(2, 8); 
		};
			
			
	$.ajax({
		url: "data.json",
		dataType:"json",
		
		success: function(data) {
			console.log(data);
			this.datas = data;

			for(var i in data) {
				player.push("Player " + data[i].playerid);
				score.push(data[i].score);
			}


			 barGraph = new Chart(ctx, {
				type: 'bar',
				data: chartdata,
				options: {
					responsive: true,
                    legend: {
                        position: 'top',
                    },
					title: {
                        display: true,
                        text: 'Chart.js Bar Chart'
                    },
					scales: {
                    xAxes: [{
                        display: true,
                        scaleLabel: {
                            display: true,
                            labelString: 'Month'
                        }
                    }],
                    yAxes: [{
                        display: true,
                        scaleLabel: {
                            display: true,
                            labelString: 'Value'
                        }
                    }]
                }
										
					
				}
								
			});
			
			
		},
		error: function(data) {
			console.log(data);
		}
	});
	
	var color = Chart.helpers.color;
	chartdata = {
				labels: player,
				datasets : [
					{
						label: 'Player Score',
						backgroundColor: randomColorGenerator(),
						borderColor: randomColorGenerator(),
						//borderColor: 'rgba(200, 200, 200, 0.75)',
						hoverBackgroundColor: 'rgba(200, 200, 200, 1)',
						hoverBorderColor: 'rgba(200, 200, 200, 1)',
						 borderWidth: 2,
						data: score
					}
				]
			};
		
});