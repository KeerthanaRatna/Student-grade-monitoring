$(document).ready(function(){
	
			var id = [];
			var maths_mark = [];
			var science_mark = [];
			var english_mark = [];
			var language_mark = [];
			var religon_mark = [];
			var history_mark = [];
			var ctx = $("#mycanvas");
			var chartdata;
			var barGraphs;
			var type = 'bar';
			
			
			var randomColorGenerator = function () { 
			return '#' + (Math.random().toString(16) + '0000000').slice(2, 8); 
		};
			var color_1 = randomColorGenerator();
			var color_2 = randomColorGenerator();
			var color_3 = randomColorGenerator();
			var color_4 = randomColorGenerator();
			var color_5 = randomColorGenerator();
			var color_6 = randomColorGenerator();
			
	$.ajax({
		url: "http://localhost/ci/index.php/home/oneclassf",
		method:"GET",
		
		
		success: function(data) {
			console.log(data);
		


			
			for(var i in data){
				id.push(data[i].indexno);
				maths_mark.push(data[i].English);
				science_mark.push(data[i].Religion);
				english_mark.push(data[i].Science);
				language_mark.push(data[i].History);
				religon_mark.push(data[i].Language);
				history_mark.push(data[i].Maths);
			}



			 barGraphs = new Chart(ctx, {
				type: 'bar',
				data: chartdata,
				options: {
					responsive: true,
                    legend: {
                        position: 'top',
                    },
					title: {
                        display: true,
                        text: 'SELECTED CLASS ALL SUBJETS MARKS ANALYSE'
                    },
					scales: {
                    xAxes: [{
                        display: true,
                        scaleLabel: {
                            display: true,
                            labelString: 'INDEX NUMBER'
                        }
                    }],
                    yAxes: [{
                        display: true,
                        scaleLabel: {
                            display: true,
                            labelString: 'MARK'
                        }
                    }]
                }
										
					
				}
				
								
			});
														
			
		},
		error: function(data) {
			console.log(data);
		}
	});
	

	chartdata = { 
				labels: id,
				datasets : [
					{	

						type: 'line', 
						data: maths_mark,
						fill:false,
						label: 'Maths mark line graph',
						backgroundColor: color_1,
						borderColor: color_1,
						borderWidth: 2,
					},
					{	

						type: 'bar', 
						data: maths_mark,
						label: 'Maths mark bar graph',
						backgroundColor: randomColorGenerator(),												
					},
					{	

						type: 'line', 
						data:science_mark,
						fill:false,
						label: 'science mark line graph',
						backgroundColor: color_2,
						borderColor:color_2,
						borderWidth: 2,
					},
					{	

						type: 'bar', 
						data: science_mark,
						label: 'Science mark bar graph',
						backgroundColor: randomColorGenerator(),												
					},
					
					{	

						type: 'line', 
						data: english_mark,
						fill:false,
						label:'English subject mark',
						backgroundColor: color_3,
						borderColor: color_3,
						borderWidth: 2,
					},
					{		

						type: 'bar', 
						data: english_mark,
						label: 'English mark bar graph',
						backgroundColor: randomColorGenerator(),												
					},
					{	

						type: 'line', 
						data: language_mark,
						fill:false,
						label: 'Language mark line graph',
						backgroundColor: color_4,
						borderColor:color_4,
						borderWidth: 2,
					},
					{	

						type: 'bar', 
						data: language_mark,
						label: 'Language mark bar graph',
						backgroundColor: randomColorGenerator(),												
					},
					{	

						type: 'line', 
						data: religon_mark,
						fill:false,
						label: 'Religon mark line graph',
						backgroundColor: color_5,
						borderColor: color_5,
						borderWidth: 2,
					},	
					{	

						type: 'bar', 
						data: religon_mark,
						label: 'Religon mark bar graph',
						backgroundColor: randomColorGenerator(),												
					},
					{	

						type: 'line', 
						data: history_mark,
						fill:false,
						label: 'History mark line graph',
						backgroundColor: color_6,
						borderColor: color_6,
						borderWidth: 2,
					},
					{	

						type: 'bar', 
						data: history_mark,
						label: 'History mark bar graph',
						backgroundColor: randomColorGenerator(),												
					}
					
					
					
				]
			}
				
				
			
			;
		
});