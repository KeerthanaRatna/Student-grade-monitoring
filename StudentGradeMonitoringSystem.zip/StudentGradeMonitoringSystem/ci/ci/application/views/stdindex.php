<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Sign-Up/Login Form</title>
  <link href="http://localhost/ci/css/googlesheet.css" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="http://localhost/ci/css/normalize.min.css">

  
      <link rel="stylesheet" href="http://localhost/ci/css/style.css">

  
</head>

<body>

<a href="<?php echo base_url() ?>index.php/home/teaindex"><h1>Teachers Login</h1></a>
  <div class="form">
       <h1>Sign Up for Student</h1>
      <ul class="tab-group">
        <li class="tab active"><a href="#signup_tch">Sign Up</a></li>
        <li class="tab"><a href="#login">Log In</a></li>
         <!--li class="tab"><a href="#signup_std">Sign Up</a></li-->
      </ul>
      

      <div class="tab-content">
        <div id="signup_tch">   
         
          
          <form action="<?php echo base_url() ?>index.php/home/signup" method="post">
          
          <div class="top-row">
            <div class="field-wrap">
              <label>
                First Name<span class="req">*</span>
              </label>
              <input placeholder="name" id="username" type="text" class="validate" name="username" required autocomplete="off" />
            </div>
        
            <div class="field-wrap">
              <label>
                Last Name<span class="req">*</span>
              </label>
              <input type="text" required autocomplete="off"/>
            </div>
          </div>

          <div class="field-wrap">
            <label>
              User Name<span class="req">*</span>
            </label>
            <input placeholder="indexno" id="indexno" type="text" class="validate" name="indexno" required autocomplete="off"/>
          </div>
          
          <div class="field-wrap">
            <label>
              Set A Password<span class="req">*</span>
            </label>
            <input type="password"required autocomplete="off"/>
          </div>

           <div class="field-wrap">
            <label>
             Confirm Password<span class="req">*</span>
            </label>
            <input placeholder="password" id="password" type="password" class="validate" name="password" required autocomplete="off"/>
          </div>
          
          <button type="submit" class="button button-block"/>Submit</button>
          
          </form>

        </div>
        


      
        <div id="login">   
          <h1>Welcome Back!</h1>
          
          <form action="<?php echo base_url() ?>index.php/home/login_connect_db" method="post">
          
            <div class="field-wrap">

            <label>
              User Name<span class="req">*</span>
            </label>
            <input  id="name" type="text" class="validate" name="username" required autocomplete="off"/>
          </div>
          
          <div class="field-wrap">
            <label>
              Password<span class="req">*</span>
            </label>
            <input  id="password" type="password" class="validate" name="password" required autocomplete="off"/>
          </div>
          
          <p class="forgot"><a href="#">Forgot Password?</a></p>
          
          <button class="button button-block"/>Log In</button>
          
          </form>

        </div>



       

    
      </div><!-- tab-content -->
      
</div> <!-- /form -->
  <script src='http://localhost/ci/js/jquery.min.js'></script>

    <script src="http://localhost/ci/js/index.js"></script>

</body>
</html>
